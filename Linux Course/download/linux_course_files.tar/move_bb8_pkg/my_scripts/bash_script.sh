#!/bin/bash

echo Hello there, Developers!
