cd ~/catkin_ws/src/linux_course_files/move_bb8_pkg/my_scripts
ls -la
chmod 777 move_bb8_square.py
ls -la
